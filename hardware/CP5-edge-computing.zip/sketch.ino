/*
 * ============================================================
 * CP5 — Vinheria Agnello | IoT Full + Dashboard
 * ============================================================
 * Integrantes:
 *   João Victor Melo  (566640)
 *   Gustavo Macedo    (567594)
 *   Gustavo Hiruo     (567625)
 *   Yan Lucas         (567046)
 *
 * Autor original: Fábio Henrique Cabrini
 * Turma: 1ESPA — FIAP 2026
 *
 * Resumo:
 *   O ESP32 coleta dados de luminosidade (LDR), temperatura e
 *   umidade (DHT11) e os publica via MQTT no FIWARE.
 *   A lógica de decisão foi REMOVIDA do hardware (edge) e
 *   transferida para o dashboard Python (fog/cloud computing).
 *   O ESP32 apenas COLETA e OBEDECE comandos vindos do FIWARE:
 *     - Piscar LED azul onboard quando há anomalia
 *     - Acionar buzzer com som específico por tipo de anomalia
 *     - Parar alertas quando os valores voltam ao normal
 *
 * Revisões:
 *   Rev1: 26-08-2023 - Portado para ESP32 com LDR
 *         Autor: Lucas Demetrius Augusto
 *   Rev2: 28-08-2023 - Ajustes FIWARE Descomplicado
 *         Autor: Fábio Henrique Cabrini
 *   Rev3: 01-11-2023 - Refinamento FIWARE Descomplicado
 *         Autor: Fábio Henrique Cabrini
 *   Rev4: 29-03-2026 - Adaptação CP4 (LDR + FIWARE)
 *         Autores: João Victor, Gustavo Macedo, Gustavo Hiruo, Yan Lucas
 *   Rev5: 02-05-2026 - CP5: adição DHT11, Buzzer, comandos de alerta
 *         Autores: João Victor, Gustavo Macedo, Gustavo Hiruo, Yan Lucas
 * ============================================================
 */

#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

// ============================================================
// CONFIGURAÇÕES DE REDE E MQTT
// ============================================================
const char* default_SSID          = "Wokwi-GUEST";       // Rede Wi-Fi (Wokwi-GUEST para simulação)
const char* default_PASSWORD      = "";                    // Senha Wi-Fi (vazia no Wokwi)
const char* default_BROKER_MQTT   = "20.124.178.183";     // IP da VM Azure com FIWARE
const int   default_BROKER_PORT   = 1883;                  // Porta padrão MQTT

// ============================================================
// TÓPICOS MQTT
// ============================================================
const char* default_TOPICO_SUBSCRIBE  = "/TEF/vinheria001/cmd";      // Recebe comandos do FIWARE
const char* default_TOPICO_PUBLISH_1  = "/TEF/vinheria001/attrs";    // Publica estado geral
const char* default_TOPICO_PUBLISH_2  = "/TEF/vinheria001/attrs/l";  // Publica luminosidade
const char* default_TOPICO_PUBLISH_3  = "/TEF/vinheria001/attrs/t";  // Publica temperatura
const char* default_TOPICO_PUBLISH_4  = "/TEF/vinheria001/attrs/h";  // Publica umidade
const char* default_ID_MQTT           = "vinheria001";               // ID do dispositivo MQTT
const char* topicPrefix               = "vinheria001";               // Prefixo para comparação de comandos

// ============================================================
// PINOS DO HARDWARE
// ============================================================
const int PIN_LED    = 2;    // LED azul onboard do ESP32
const int PIN_BUZZER = 18;   // Buzzer passivo (pino digital)
const int PIN_LDR    = 34;   // Sensor LDR (pino analógico)
const int PIN_DHT    = 4;    // Sensor DHT11 (pino digital)
#define   TIPO_DHT   DHT22   // Define o modelo do sensor DHT

// ============================================================
// VARIÁVEIS DE ESTADO
// ============================================================
char EstadoSaida = '0';   // Estado atual do LED ('0' = off, '1' = on)
bool alertaAtivo = false; // Indica se há algum alerta ativo no momento
int  tipoAlerta  = 0;     // 0=nenhum, 1=luminosidade, 2=temperatura, 3=umidade, 4=múltiplos

// Variáveis para controle de tempo sem usar delay() no loop principal
unsigned long ultimoEnvio      = 0;  // Último momento em que os sensores foram publicados
unsigned long ultimoPisca      = 0;  // Último momento em que o LED piscou
bool          estadoLED        = false; // Estado atual do LED durante pisca-pisca

const long INTERVALO_SENSORES  = 3000;  // Envia leituras a cada 3 segundos
const long INTERVALO_PISCA     = 500;   // LED pisca a cada 500ms quando há alerta

// Ponteiros editáveis para as configurações (padrão FIWARE Descomplicado)
char* SSID         = const_cast<char*>(default_SSID);
char* PASSWORD     = const_cast<char*>(default_PASSWORD);
char* BROKER_MQTT  = const_cast<char*>(default_BROKER_MQTT);
int   BROKER_PORT  = default_BROKER_PORT;
char* TOPICO_SUB   = const_cast<char*>(default_TOPICO_SUBSCRIBE);
char* TOPICO_PUB1  = const_cast<char*>(default_TOPICO_PUBLISH_1);
char* TOPICO_PUB2  = const_cast<char*>(default_TOPICO_PUBLISH_2);
char* TOPICO_PUB3  = const_cast<char*>(default_TOPICO_PUBLISH_3);
char* TOPICO_PUB4  = const_cast<char*>(default_TOPICO_PUBLISH_4);
char* ID_MQTT      = const_cast<char*>(default_ID_MQTT);

// Objetos principais
WiFiClient    espClient;
PubSubClient  MQTT(espClient);
DHT           dht(PIN_DHT, TIPO_DHT);

// ============================================================
// SETUP — Executado uma única vez ao ligar o ESP32
// ============================================================
void setup() {
    initPinos();
    initSerial();
    initWiFi();
    initMQTT();
    dht.begin(); // Inicializa o sensor DHT11

    delay(3000); // Aguarda estabilização da conexão

    // Anuncia que o dispositivo está online
    MQTT.publish(TOPICO_PUB1, "s|on");
    Serial.println("=== Vinheria Agnello CP5 - Dispositivo Online ===");
}

// ============================================================
// LOOP — Executado continuamente
// ============================================================
void loop() {
    verificaConexoes();   // Mantém WiFi e MQTT conectados
    MQTT.loop();          // Processa mensagens MQTT recebidas

    unsigned long agora = millis();

    // Publica leituras dos sensores a cada INTERVALO_SENSORES ms
    if (agora - ultimoEnvio >= INTERVALO_SENSORES) {
        ultimoEnvio = agora;
        publicarSensores();
        publicarEstadoLED();
    }

    // Pisca o LED se houver alerta ativo
    if (alertaAtivo) {
        if (agora - ultimoPisca >= INTERVALO_PISCA) {
            ultimoPisca = agora;
            estadoLED = !estadoLED;
            digitalWrite(PIN_LED, estadoLED);
        }
    }
}

// ============================================================
// INICIALIZAÇÃO DOS PINOS
// ============================================================
void initPinos() {
    pinMode(PIN_LED,    OUTPUT);
    pinMode(PIN_BUZZER, OUTPUT);

    // Sequência de pisca inicial para confirmar que o hardware está OK
    for (int i = 0; i < 6; i++) {
        digitalWrite(PIN_LED, i % 2 == 0);
        delay(150);
    }
    digitalWrite(PIN_LED, LOW); // Garante LED desligado ao iniciar
    noTone(PIN_BUZZER);         // Garante buzzer silencioso ao iniciar
}

// ============================================================
// INICIALIZAÇÃO DA SERIAL
// ============================================================
void initSerial() {
    Serial.begin(115200);
    Serial.println("Serial iniciada.");
}

// ============================================================
// INICIALIZAÇÃO DO WI-FI
// ============================================================
void initWiFi() {
    Serial.println("------ Conexão Wi-Fi ------");
    Serial.print("Conectando em: ");
    Serial.println(SSID);
    reconectWiFi();
}

// ============================================================
// RECONEXÃO WI-FI
// ============================================================
void reconectWiFi() {
    if (WiFi.status() == WL_CONNECTED) return;

    WiFi.begin(SSID, PASSWORD);
    while (WiFi.status() != WL_CONNECTED) {
        delay(100);
        Serial.print(".");
    }
    Serial.println();
    Serial.print("Wi-Fi conectado! IP: ");
    Serial.println(WiFi.localIP());
    digitalWrite(PIN_LED, LOW); // LED apagado após reconexão
}

// ============================================================
// INICIALIZAÇÃO DO MQTT
// ============================================================
void initMQTT() {
    MQTT.setServer(BROKER_MQTT, BROKER_PORT);
    MQTT.setCallback(mqtt_callback);
}

// ============================================================
// RECONEXÃO MQTT
// ============================================================
void reconnectMQTT() {
    while (!MQTT.connected()) {
        Serial.print("Conectando ao broker MQTT: ");
        Serial.println(BROKER_MQTT);
        if (MQTT.connect(ID_MQTT)) {
            Serial.println("Conectado ao broker MQTT!");
            MQTT.subscribe(TOPICO_SUB); // Inscreve para receber comandos do FIWARE
        } else {
            Serial.println("Falha na conexão. Tentando em 2s...");
            delay(2000);
        }
    }
}

// ============================================================
// VERIFICA CONEXÕES (chamado no loop)
// ============================================================
void verificaConexoes() {
    if (!MQTT.connected()) reconnectMQTT();
    reconectWiFi();
}

// ============================================================
// CALLBACK MQTT — Processa comandos recebidos do FIWARE/Python
//
// Comandos esperados:
//   vinheria001@on|           → liga LED (alerta ativo)
//   vinheria001@off|          → desliga LED (sem alerta)
//   vinheria001@alerta_lum|   → buzzer: luminosidade fora do normal
//   vinheria001@alerta_temp|  → buzzer: temperatura fora do normal
//   vinheria001@alerta_hum|   → buzzer: umidade fora do normal
//   vinheria001@alerta_mult|  → buzzer: múltiplos problemas (som contínuo)
//   vinheria001@sem_alerta|   → desliga todos os alertas
// ============================================================
void mqtt_callback(char* topic, byte* payload, unsigned int length) {
    String msg = "";
    for (int i = 0; i < length; i++) {
        msg += (char)payload[i];
    }

    Serial.print("Comando recebido: ");
    Serial.println(msg);

    // --- Controle do LED ---
    if (msg.equals(String(topicPrefix) + "@on|")) {
      alertaAtivo = true;
      EstadoSaida = '1';
      tone(PIN_BUZZER, 1500);
      Serial.println("→ Alerta ativado: LED piscando + buzzer tocando.");
    }

    if (msg.equals(String(topicPrefix) + "@off|")) {
        alertaAtivo = false;
        EstadoSaida = '0';
        digitalWrite(PIN_LED, LOW);
        noTone(PIN_BUZZER);
        Serial.println("→ Alerta desativado: LED e buzzer desligados.");
    }

    // --- Alertas sonoros por tipo de anomalia ---

    // LUMINOSIDADE: beeps curtos e rápidos (2 bips)
    if (msg.equals(String(topicPrefix) + "@alerta_lum|")) {
        tipoAlerta = 1;
        alertaSonoro_Luminosidade();
    }

    // TEMPERATURA: beep longo + curto (padrão morse SOS simplificado)
    if (msg.equals(String(topicPrefix) + "@alerta_temp|")) {
        tipoAlerta = 2;
        alertaSonoro_Temperatura();
    }

    // UMIDADE: três beeps médios
    if (msg.equals(String(topicPrefix) + "@alerta_hum|")) {
        tipoAlerta = 3;
        alertaSonoro_Umidade();
    }

    // MÚLTIPLOS PROBLEMAS: som contínuo (o operador já sabe o que fazer)
    if (msg.equals(String(topicPrefix) + "@alerta_mult|")) {
        tipoAlerta = 4;
        tone(PIN_BUZZER, 1000); // Tom contínuo em 1kHz
        Serial.println("→ Múltiplos alertas: buzzer contínuo ativado.");
    }

    // SEM ALERTA: desliga tudo
    if (msg.equals(String(topicPrefix) + "@sem_alerta|")) {
        tipoAlerta = 0;
        alertaAtivo = false;
        EstadoSaida = '0';
        digitalWrite(PIN_LED, LOW);
        noTone(PIN_BUZZER);
        Serial.println("→ Sem alertas: tudo normalizado.");
    }
}

// ============================================================
// SONS DE ALERTA — Cada anomalia tem um padrão sonoro único
// ============================================================

// Luminosidade: 2 bips rápidos e agudos (frequência alta = luz)
void alertaSonoro_Luminosidade() {
    Serial.println("→ Alerta de LUMINOSIDADE ativado.");
    tone(PIN_BUZZER, 2000, 100); delay(200);
    tone(PIN_BUZZER, 2000, 100); delay(200);
}

// Temperatura: 1 bip longo grave (frequência baixa = calor pesado)
void alertaSonoro_Temperatura() {
    Serial.println("→ Alerta de TEMPERATURA ativado.");
    tone(PIN_BUZZER, 500, 600); delay(700);
}

// Umidade: 3 bips médios (frequência média)
void alertaSonoro_Umidade() {
    Serial.println("→ Alerta de UMIDADE ativado.");
    tone(PIN_BUZZER, 1200, 200); delay(300);
    tone(PIN_BUZZER, 1200, 200); delay(300);
    tone(PIN_BUZZER, 1200, 200); delay(300);
}

// ============================================================
// PUBLICA LEITURAS DOS SENSORES VIA MQTT
// ============================================================
void publicarSensores() {
    // --- Luminosidade (LDR) ---
    int rawLDR     = analogRead(PIN_LDR);
    int luminosity = map(rawLDR, 0, 4095, 0, 100); // Mapeia 0-4095 para 0-100%
    String msgLum  = String(luminosity);
    MQTT.publish(TOPICO_PUB2, msgLum.c_str());
    Serial.print("Luminosidade publicada: "); Serial.println(msgLum);

    // --- Temperatura (DHT11) ---
    float temperatura = dht.readTemperature();
    if (!isnan(temperatura)) { // Só publica se a leitura for válida
        String msgTemp = String(temperatura, 1); // 1 casa decimal
        MQTT.publish(TOPICO_PUB3, msgTemp.c_str());
        Serial.print("Temperatura publicada: "); Serial.println(msgTemp);
    } else {
        Serial.println("ERRO: Falha na leitura do DHT11 (temperatura).");
    }

    // --- Umidade (DHT11) ---
    float umidade = dht.readHumidity();
    if (!isnan(umidade)) {
        String msgHum = String(umidade, 1);
        MQTT.publish(TOPICO_PUB4, msgHum.c_str());
        Serial.print("Umidade publicada: "); Serial.println(msgHum);
    } else {
        Serial.println("ERRO: Falha na leitura do DHT11 (umidade).");
    }
}

// ============================================================
// PUBLICA ESTADO DO LED VIA MQTT
// ============================================================
void publicarEstadoLED() {
    if (EstadoSaida == '1') {
        MQTT.publish(TOPICO_PUB1, "s|on");
    } else {
        MQTT.publish(TOPICO_PUB1, "s|off");
    }
}
